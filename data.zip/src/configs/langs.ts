export const langs = {
    en: {
      short: "en",
      full: "English",
      dir: "ltr",
    },
    fa: {
      short: "fa",
      full: "فارسی",
      dir: "rtl",
    },
  };