import React from 'react'

function Prize() {
  return (
    <div>
      
    </div>
  )
}

export default Prize
